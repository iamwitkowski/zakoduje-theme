import adminMenu from './components/adminMenu'
import mediaSVG from './components/mediaSVG'

jQuery( document ).ready( function() {
  adminMenu.init();
  mediaSVG.init();
});
