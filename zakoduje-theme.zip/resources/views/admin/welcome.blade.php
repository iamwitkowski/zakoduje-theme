<div class="welcome-panel-content">
  <h2>
    {!! apply_filters('zkd_dashboard_welcome_title', sprintf(__('Welcome into <b>%1$s</b>', 'zkd'), get_bloginfo('name'))) !!}
  </h2>
  <p class="about-description">
    {!! apply_filters('zkd_dashboard_welcome_title', __('Please select what you want to do.')) !!}
  </p>
</div>
