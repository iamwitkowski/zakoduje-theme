<header class="page-header wrapper">
  <h1 class="page-header__heading">
    {!! App::title() !!}
  </h1>
</header>
