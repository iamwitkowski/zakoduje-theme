<div class="wrapper">
  @php the_content() @endphp
</div>
